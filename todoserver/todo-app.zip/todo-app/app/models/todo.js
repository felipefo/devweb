var connection = require ('../config/connection');

function Todo() {
  this.get = function(res) {
    connection.acquire(function(err,con) {
      con.query('select * from tarefas', function(err,result) {
        con.release();
        res.send(result);
        console.log("Get successful");
      });
    });
  };
  this.getByID = function(id,res) {
    connection.acquire(function(err,con) {
      console.log("id eh: " + id);
      //sem a protecao de sql injection
      con.query("select * from tarefas where id = " + id ,  function(err,result) {
        //ATAQUE DE SQL IJECTION: //todo/251115893%20UNION%20ALL%20Select%20*%20from%20tarefas
      
      //com a protecao do sql injeciton
      //con.query("select * from tarefas where id = ?",  id, function(err,result) {
        con.release();
        
      
        
        console.log(result);
        res.send(result);
        console.log("Get by ID successful");
      });
    });
  };
  this.create = function(todo,res) {
    connection.acquire(function(err,con) {
      con.query('insert into tarefas set ?', todo, function(err,result) {
        con.release();
        if (err) {
          res.send( 'TODO creation fail');
        } else {
          res.send('TODO create success');
          console.log("Post successful");
        }
      });
    });
  };
  this.update = function(todo,id,res) {
    connection.acquire(function(err,con) {
      con.query('update tarefas set descricao = ? where id = ?', [todo, id], function(err,result) {
        con.release();
        if (err) {
          res.send({status:1, message:'TODO update fail'});
        } else {
          res.send({status:0, message:'TODO update success'});
          console.log("Put successful");
        }
      });
    });
  };
  this.delete = function(id,res) {
    connection.acquire(function(err,con) {
      con.query('delete from tarefas where id = ?', id, function(err,result) {
        con.release();
        if (err) {
          res.send({status:1, message:'TODO delete fail'});
        } else {
          res.send({status:0, message:'TODO delete success'});
          console.log("Delete successful");
        }
      });
    });
  };
};

module.exports = new Todo();
