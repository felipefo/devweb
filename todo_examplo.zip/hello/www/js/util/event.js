function Event(sender) {
    this._sender = sender;
    this._listeners = [];
}

Event.prototype = {
    attach : function (listener) {
    	console.log("attach");
        this._listeners.push(listener);
    },
    notify : function (args) {
    	console.log("evento notify:" +  args);
        var index;
        for (index = 0; index < this._listeners.length; index += 1) {
        	console.log("notificar quem??" + this._listeners[index]);    
            this._listeners[index](this._sender, args);
            
        }
    }
};