INSERT INTO `todo_list`
  (`name`)
VALUES
  ("Go to the post office"),
  ("Deposit paycheck"),
  ("Water plants"),
  ("Finish homework");
