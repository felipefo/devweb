function AtividadePersistencia(){

	this.tarefaWS = new TarefasWS(this);
	this.listaAdded = new Event(this);
	this.lista;
	this.local = false;

	this.limpar = function(){	
	    if(this.local){
	        localStorage.clear();	     
	    }else{
	        this.tarefaWS.limparTarefas();    
	    }
	}
	this.salvar =  function(atividade){	
	    if(this.local)
	        localStorage.setItem(atividade.id , atividade);		
	    else
	        this.tarefaWS.sendTarefas(atividade);        
	}
	this.getLista = function (){
		return this.lista;
	}
	this.listarTodos =  function(){			
		if(this.local){
		    var atividadestat = new Atividade();
			for(var key in localStorage) {
				var jsonObject = localStorage.getItem(key);						
				var atividade = atividadestat.toAtividade(jsonObject);			
				lista.push(atividade);
		    }
        	this.listaAdded.notify(lista);
		}
	    else
		    this.tarefaWS.getTarefas(this);
	}		
}

function TarefasWS(persistencia){    						
	this.domain = "https://todolistcomslimphp-felipefrechiani.c9users.io/slim/slim-skeleton/public/";
	//this.domain = "https://todolistcomslimphp-felipefrechiani.c9users.io:8081/";
	var persistencia = persistencia;
	this.sendTarefas = function(atividade){
        var uuid = this.getUUID();
    	$.post( this.domain + "salvartarefa",  {"status": atividade.status, "descricao": atividade.descricao, "id": atividade.id , "userid": uuid })
    	    .done(function(msg){ 
    	    persistencia.lista.push(atividade);
        	persistencia.listaAdded.notify(persistencia.lista);
	  		Materialize.toast(msg, 4000) }
	  	    )
        .fail(function(xhr, status, error) {
            alert("alguma falha");
            alert(xhr.responseText);
	        }
        )
	}
	this.limparTarefas = function(){
        var uuid = this.getUUID();
    	$.get( this.domain + "limpartarefas",  function(data, status){
    	    persistencia.lista = [];
        	persistencia.listaAdded.notify([]);
        	Materialize.toast(data, 4000);
    	});
	}
   	this.getTarefas  = function (){	
		$.get(this.domain + "tarefas", function(data, status){
			persistencia.lista = data;
        	persistencia.listaAdded.notify(data);
    	});
	}
	this.getUUID = function (){
	    var uuid = "0001"//so para testes no navegador localmente
    	try{
    		 uuid = device.uuid;
    	}catch(ex){
    		console.log(ex);
    	}
    	return uuid;
	    
	}
};